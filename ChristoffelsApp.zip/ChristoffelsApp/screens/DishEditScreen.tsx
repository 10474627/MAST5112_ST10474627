import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet, Image, TouchableOpacity, Alert, ImageSourcePropType } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { RouteProp } from "@react-navigation/native";
import { RootStackParamList } from "../App";
import { Category, Dish } from "../types";
import { launchImageLibrary } from "react-native-image-picker";

// Type-safe props
type DishEditScreenNavigationProp = StackNavigationProp<RootStackParamList, "Edit Dish">;
type DishEditScreenRouteProp = RouteProp<RootStackParamList, "Edit Dish">;

type Props = {
  navigation: DishEditScreenNavigationProp;
  route: DishEditScreenRouteProp;
  categories: Category[];
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
};

// Local placeholder image
const placeholder = require("../assets/images/placeholder.jpg");

export default function DishEditScreen({ navigation, route, categories, setCategories }: Props) {
  const category = categories.find((c) => c.id === route.params.categoryId);
  if (!category) return <Text>Category not found</Text>;

  const dish = category.dishes[route.params.dishIndex];
  if (!dish) return <Text>Dish not found</Text>;

  const [name, setName] = useState(dish.name);
  const [price, setPrice] = useState(dish.price.toString());
  const [description, setDescription] = useState(dish.description || "");
  const [dishImage, setDishImage] = useState<number | string | undefined>(dish.image);

  // Image picker function for bare React Native
  const pickImage = () => {
    launchImageLibrary(
      { mediaType: "photo", quality: 1 },
      (response) => {
        if (response.didCancel) return;
        if (response.errorCode) {
          console.log("ImagePicker Error: ", response.errorMessage);
          return;
        }
        if (response.assets && response.assets.length > 0) {
          setDishImage(response.assets[0].uri);
        }
      }
    );
  };

  const handleSave = () => {
    if (!name || !price) {
      Alert.alert("Error", "Please fill in name and price");
      return;
    }

    const updatedDish: Dish = {
      name,
      price: Number(price),
      description: description || undefined,
      image: dishImage,
    };

    const updatedCategories = categories.map((c) =>
      c.id === category.id
        ? {
            ...c,
            dishes: c.dishes.map((d, idx) =>
              idx === route.params.dishIndex ? updatedDish : d
            ),
          }
        : c
    );

    setCategories(updatedCategories);
    navigation.goBack();
  };

  const getImageSource = (image?: string | number): ImageSourcePropType => {
    if (!image) return placeholder;
    return typeof image === "string" ? { uri: image } : image;
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Edit Dish: {dish.name}</Text>

      {/* Dish image */}
      <View style={styles.imageContainer}>
        <Image source={getImageSource(dishImage)} style={styles.image} />
        <TouchableOpacity style={styles.imageButton} onPress={pickImage}>
          <Text style={styles.imageButtonText}>Change/Add Image</Text>
        </TouchableOpacity>
      </View>

      <TextInput
        style={styles.input}
        value={name}
        onChangeText={setName}
        placeholder="Dish Name"
      />
      <TextInput
        style={styles.input}
        value={price}
        onChangeText={setPrice}
        keyboardType="numeric"
        placeholder="Price"
      />
      <TextInput
        style={styles.input}
        value={description}
        onChangeText={setDescription}
        placeholder="Description (optional)"
      />

      <Button title="Save Changes" onPress={handleSave} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 20, fontWeight: "bold", marginBottom: 20 },
  input: { borderWidth: 1, borderColor: "#ccc", padding: 10, marginBottom: 10, borderRadius: 5 },
  imageContainer: { alignItems: "center", marginBottom: 16 },
  image: { width: 150, height: 150, borderRadius: 8, marginBottom: 8, backgroundColor: "#ddd" },
  imageButton: { backgroundColor: "#007bff", padding: 8, borderRadius: 6 },
  imageButtonText: { color: "#fff", fontWeight: "bold" },
});
