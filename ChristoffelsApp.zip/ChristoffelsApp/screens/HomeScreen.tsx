import React, { useState, useMemo } from "react";
import { View, Text, FlatList, TouchableOpacity, Image, StyleSheet, Alert, ImageSourcePropType } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { RootStackParamList } from "../App";
import { Category, Dish } from "../types";

// --- Local image imports ---
const logo = require("../assets/images/logo.png");
const placeholder = require("../assets/images/placeholder.jpg"); // fallback if dish image missing

type HomeScreenNavigationProp = StackNavigationProp<RootStackParamList, "Home">;

type Props = {
  navigation: HomeScreenNavigationProp;
  categories: Category[];
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
};

export default function HomeScreen({ navigation, categories, setCategories }: Props) {
  const [filter, setFilter] = useState<"All" | "Starters" | "Main Meal" | "Dessert">("All");

  // Flatten dishes with category info
  const filteredDishes = useMemo(() =>
    categories.flatMap(category =>
      filter === "All" || category.name === filter
        ? category.dishes.map((dish, index) => ({ ...dish, categoryId: category.id, dishIndex: index }))
        : []
    ),
    [filter, categories]
  );

  // Calculate average price
  const averagePrice = useMemo(() => {
    if (filteredDishes.length === 0) return 0;
    return filteredDishes.reduce((sum, dish) => sum + dish.price, 0) / filteredDishes.length;
  }, [filteredDishes]);

  // Delete dish
  const deleteDish = (categoryId: number, dishIndex: number) => {
    Alert.alert(
      "Delete Dish",
      "Are you sure you want to delete this dish?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            setCategories(prev =>
              prev.map(c =>
                c.id === categoryId ? { ...c, dishes: c.dishes.filter((_, i) => i !== dishIndex) } : c
              )
            );
          },
        },
      ]
    );
  };

  // Helper to get proper ImageSourcePropType
  const getImageSource = (image?: string | number): ImageSourcePropType => {
    if (!image) return placeholder;
    return typeof image === "string" ? { uri: image } : image;
  };

  return (
    <View style={styles.container}>
      {/* Logo */}
      <Image source={logo} style={styles.logo} />

      {/* Filter buttons */}
      <View style={styles.filterRow}>
        {["All", "Starters", "Main Meal", "Dessert"].map(type => (
          <TouchableOpacity
            key={type}
            style={[styles.filterButton, filter === type && styles.activeFilter]}
            onPress={() => setFilter(type as any)}
          >
            <Text style={styles.filterText}>{type}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Average price */}
      <Text style={styles.average}>Average Price: R {averagePrice.toFixed(2)}</Text>

      {/* Dish list */}
      <FlatList
        data={filteredDishes}
        keyExtractor={item => `${item.categoryId}-${item.dishIndex}`}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={getImageSource(item.image)} style={styles.image} />
            <View style={styles.info}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.price}>R {item.price}</Text>
              {item.description && <Text style={styles.desc}>{item.description}</Text>}
            </View>
            <View style={styles.buttons}>
              <TouchableOpacity
                style={styles.editButton}
                onPress={() =>
                  navigation.navigate("Edit Dish", { categoryId: item.categoryId, dishIndex: item.dishIndex })
                }
              >
                <Text style={styles.buttonText}>Edit</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.deleteButton}
                onPress={() => deleteDish(item.categoryId, item.dishIndex)}
              >
                <Text style={styles.buttonText}>Delete</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />

      {/* Add dish button */}
      <TouchableOpacity style={styles.addButton} onPress={() => navigation.navigate("Add Dish", { categoryId: 0 })}>
        <Text style={styles.addButtonText}>+ Add Dish</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#fff" },
  logo: { width: 150, height: 150, alignSelf: "center", marginBottom: 16 },
  filterRow: { flexDirection: "row", justifyContent: "space-around", marginBottom: 12 },
  filterButton: { padding: 8, borderRadius: 6, backgroundColor: "#eee" },
  activeFilter: { backgroundColor: "#cce5ff" },
  filterText: { fontWeight: "bold" },
  average: { textAlign: "center", marginBottom: 8, fontSize: 14, fontWeight: "bold" },
  card: { flexDirection: "row", padding: 12, marginBottom: 10, borderRadius: 8, backgroundColor: "#f8f8f8", alignItems: "center", elevation: 2 },
  image: { width: 60, height: 60, borderRadius: 8, marginRight: 12, backgroundColor: "#ddd" },
  info: { flex: 1 },
  name: { fontSize: 16, fontWeight: "bold" },
  price: { fontSize: 14, color: "green", marginTop: 4 },
  desc: { fontSize: 12, color: "#555", marginTop: 2 },
  buttons: { flexDirection: "row", marginLeft: 8 },
  editButton: { backgroundColor: "#4caf50", padding: 6, borderRadius: 4, marginRight: 4 },
  deleteButton: { backgroundColor: "#f44336", padding: 6, borderRadius: 4 },
  buttonText: { color: "#fff", fontSize: 12 },
  addButton: { backgroundColor: "#007bff", padding: 12, borderRadius: 6, alignItems: "center", marginTop: 12 },
  addButtonText: { color: "#fff", fontSize: 16, fontWeight: "bold" },
});
