import React from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { RouteProp } from "@react-navigation/native";
import { RootStackParamList } from "../App";
import { Category, Dish } from "../types";

// Type-safe props
type CategoryScreenNavigationProp = StackNavigationProp<RootStackParamList, "Category">;
type CategoryScreenRouteProp = RouteProp<RootStackParamList, "Category">;

type Props = {
  navigation: CategoryScreenNavigationProp;
  route: CategoryScreenRouteProp;
  categories: Category[];
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
};

export default function CategoryScreen({ navigation, route, categories, setCategories }: Props) {
  const category = categories.find((c) => c.id === route.params.categoryId);

  if (!category) return <Text>Category not found</Text>;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{category.name}</Text>
      <FlatList
        data={category.dishes}
        keyExtractor={(_, index) => index.toString()}
        renderItem={({ item, index }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() =>
              navigation.navigate("Edit Dish", { categoryId: category.id, dishIndex: index })
            }
          >
            <Text style={styles.cardTitle}>{item.name}</Text>
            <Text>Price: R{item.price}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text>No dishes yet</Text>}
      />
      <TouchableOpacity
        style={styles.addButton}
        onPress={() => navigation.navigate("Add Dish", { categoryId: category.id })}
      >
        <Text style={styles.addButtonText}>Add Dish</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20 },
  card: { padding: 15, backgroundColor: "#eee", marginBottom: 10, borderRadius: 10 },
  cardTitle: { fontSize: 18, fontWeight: "bold" },
  addButton: { padding: 15, backgroundColor: "#4CAF50", borderRadius: 10, marginTop: 10 },
  addButtonText: { color: "#fff", textAlign: "center", fontWeight: "bold" },
});
