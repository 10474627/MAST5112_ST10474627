export type RootStackParamList = {
  Home: undefined;
  Category: { categoryId: number };
  "Add Dish": { categoryId: number };
  "Edit Dish": { categoryId: number; dishIndex: number };
};

export type Dish = {
  name: string;
  price: number;
  description?: string;
  image?: number | string;
};

export type Category = {
  id: number;
  name: string;
  averagePrice: number;
  dishes: Dish[];
};
