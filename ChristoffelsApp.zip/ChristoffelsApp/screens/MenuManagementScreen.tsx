import React, { useState } from "react";
import { View, Text, FlatList, Button, StyleSheet, TextInput, Alert } from "react-native";
import { Picker } from "@react-native-picker/picker"; // updated
import { Category, Dish } from "../types";

type Props = {
  categories: Category[];
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
};

export default function MenuManagementScreen({ categories, setCategories }: Props) {
  const [selectedCategory, setSelectedCategory] = useState<number>(categories[0]?.id || 1);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");

  const handleAddDish = () => {
    if (!name || !price) {
      Alert.alert("Error", "Please enter both a dish name and price.");
      return;
    }

    const newDish: Dish = {
      name,
      price: Number(price),
      description: description || undefined,
    };

    const updatedCategories = categories.map((c) =>
      c.id === selectedCategory ? { ...c, dishes: [...c.dishes, newDish] } : c
    );

    setCategories(updatedCategories);
    setName("");
    setPrice("");
    setDescription("");
    Alert.alert("Success", "Dish added successfully!");
  };

  const handleDeleteDish = (categoryId: number, dishIndex: number) => {
    const updatedCategories = categories.map((c) =>
      c.id === categoryId
        ? { ...c, dishes: c.dishes.filter((_, index) => index !== dishIndex) }
        : c
    );
    setCategories(updatedCategories);
    Alert.alert("Deleted", "Dish removed successfully!");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Menu Management</Text>

      <Text style={styles.label}>Choose Category</Text>
      <View style={styles.pickerContainer}>
        <Picker
          selectedValue={selectedCategory}
          onValueChange={(itemValue) => setSelectedCategory(Number(itemValue))}
        >
          {categories.map((c) => (
            <Picker.Item key={c.id} label={c.name} value={c.id} />
          ))}
        </Picker>
      </View>

      <TextInput
        style={styles.input}
        placeholder="Dish Name"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Price"
        value={price}
        onChangeText={setPrice}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Description (optional)"
        value={description}
        onChangeText={setDescription}
      />

      <Button title="Add Dish" onPress={handleAddDish} />

      <Text style={styles.subtitle}>Current Menu</Text>

      <FlatList
        data={categories}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.categoryCard}>
            <Text style={styles.categoryTitle}>{item.name}</Text>
            {item.dishes.length > 0 ? (
              item.dishes.map((dish, index) => (
                <View key={`${item.id}-${index}`} style={styles.dishRow}>
                  <Text>{dish.name} - R{dish.price}</Text>
                  <Button
                    title="Delete"
                    color="red"
                    onPress={() => handleDeleteDish(item.id, index)}
                  />
                </View>
              ))
            ) : (
              <Text style={styles.noDishes}>No dishes in this category</Text>
            )}
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#fff" },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20 },
  subtitle: { fontSize: 20, fontWeight: "600", marginVertical: 15 },
  label: { fontWeight: "600", marginVertical: 10 },
  pickerContainer: { borderWidth: 1, borderColor: "#ccc", marginBottom: 20, borderRadius: 5 },
  input: { borderWidth: 1, borderColor: "#ccc", padding: 10, marginBottom: 10, borderRadius: 5 },
  categoryCard: { padding: 15, borderWidth: 1, borderRadius: 10, marginBottom: 20, borderColor: "#ccc" },
  categoryTitle: { fontSize: 18, fontWeight: "bold", marginBottom: 10 },
  dishRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 5 },
  noDishes: { fontStyle: "italic", color: "gray" },
});
