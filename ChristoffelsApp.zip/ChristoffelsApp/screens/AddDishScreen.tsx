import React, { useState } from "react";
import { View, Text, FlatList, Button, StyleSheet, TextInput, Alert } from "react-native";
import { Picker } from "@react-native-picker/picker";
import { Category, Dish } from "../types";

type Props = {
  categories: Category[];
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
};

export default function AddDishScreen({ categories, setCategories }: Props) {
  const [selectedCategory, setSelectedCategory] = useState<number>(
    categories[0]?.id || 0
  );
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");

  const handleAddDish = () => {
    if (!name.trim() || !price.trim()) {
      Alert.alert("Error", "Please enter both a dish name and price.");
      return;
    }

    const priceNumber = Number(price);
    if (isNaN(priceNumber) || priceNumber <= 0) {
      Alert.alert("Error", "Price must be a valid number greater than 0.");
      return;
    }

    const newDish: Dish = {
      name: name.trim(),
      price: priceNumber,
      description: description.trim() || undefined,
    };

    const updatedCategories = categories.map((c) =>
      c.id === selectedCategory
        ? { ...c, dishes: [...c.dishes, newDish] }
        : c
    );

    setCategories(updatedCategories);
    setName("");
    setPrice("");
    setDescription("");
    Alert.alert("Success", "Dish added successfully!");
  };

  const handleDeleteDish = (dishIndex: number) => {
    const updatedCategories = categories.map((c) =>
      c.id === selectedCategory
        ? { ...c, dishes: c.dishes.filter((_, i) => i !== dishIndex) }
        : c
    );
    setCategories(updatedCategories);
  };

  const selectedCategoryObj = categories.find(c => c.id === selectedCategory);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Add Dish</Text>

      <Text style={styles.label}>Choose Category</Text>
      <View style={styles.pickerContainer}>
        <Picker
          selectedValue={selectedCategory}
          onValueChange={(itemValue) => setSelectedCategory(Number(itemValue))}
        >
          {categories.map((c) => (
            <Picker.Item key={c.id} label={c.name} value={c.id} />
          ))}
        </Picker>
      </View>

      <TextInput
        style={styles.input}
        placeholder="Dish Name"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Price"
        value={price}
        onChangeText={setPrice}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Description (optional)"
        value={description}
        onChangeText={setDescription}
      />

      <Button title="Add Dish" onPress={handleAddDish} />

      <Text style={styles.subtitle}>Current Menu for {selectedCategoryObj?.name}</Text>

      {selectedCategoryObj && selectedCategoryObj.dishes.length > 0 ? (
        <FlatList
          data={selectedCategoryObj.dishes}
          keyExtractor={(_, index) => index.toString()}
          renderItem={({ item, index }) => (
            <View style={styles.dishRow}>
              <Text>{item.name} - R{item.price}</Text>
              <Button
                title="Delete"
                color="red"
                onPress={() => handleDeleteDish(index)}
              />
            </View>
          )}
        />
      ) : (
        <Text style={styles.noDishes}>No dishes in this category</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#fff" },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20 },
  subtitle: { fontSize: 20, fontWeight: "600", marginVertical: 15 },
  label: { fontWeight: "600", marginVertical: 10 },
  pickerContainer: {
    borderWidth: 1,
    borderColor: "#ccc",
    marginBottom: 20,
    borderRadius: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  dishRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  noDishes: { fontStyle: "italic", color: "gray" },
});
