import React, { useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

import HomeScreen from "./screens/HomeScreen";
import CategoryScreen from "./screens/CategoryScreen";
import AddDishScreen from "./screens/AddDishScreen";
import MenuManagementScreen from "./screens/MenuManagementScreen";
import DishEditScreen from "./screens/DishEditScreen";

import { Category } from "./types";

// --- Local image imports (all use require) ---
const garlicBread = require("./assets/images/garlicbread.jpg");
const soup = require("./assets/images/soup.jpg");
const grilledChicken = require("./assets/images/chicken.jpg");
const steakNChips = require("./assets/images/steaknchips.jpg");
const lavaCake = require("./assets/images/lavacake.jpg");
const cheesecake = require("./assets/images/cheesecake.jpg");

export type RootStackParamList = {
  Home: undefined;
  Category: { categoryId: number };
  "Menu Management": undefined;
  "Edit Dish": { categoryId: number; dishIndex: number };
  "Add Dish": { categoryId: number };
};

const Stack = createStackNavigator<RootStackParamList>();

export default function App() {
  const [categories, setCategories] = useState<Category[]>([
    {
      id: 1,
      name: "Starters",
      dishes: [
        {
          name: "Garlic Bread",
          price: 150,
          description: "Toasted bread with garlic butter",
          image: garlicBread,
        },
        {
          name: "Soup of the Day",
          price: 200,
          description: "Freshly made daily",
          image: soup,
        },
      ],
      averagePrice: 0,
    },
    {
      id: 2,
      name: "Main Meal",
      dishes: [
        {
          name: "Grilled Chicken",
          price: 700,
          description: "Served with seasonal vegetables",
          image: grilledChicken,
        },
        {
          name: "Steak & Chips",
          price: 850,
          description: "Juicy steak with golden fries",
          image: steakNChips,
        },
      ],
      averagePrice: 0,
    },
    {
      id: 3,
      name: "Dessert",
      dishes: [
        {
          name: "Chocolate Lava Cake",
          price: 400,
          description: "With vanilla ice cream",
          image: lavaCake,
        },
        {
          name: "Cheesecake",
          price: 380,
          description: "Rich and creamy",
          image: cheesecake,
        },
      ],
      averagePrice: 0,
    },
  ]);

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home">
          {(props) => (
            <HomeScreen
              {...props}
              categories={categories}
              setCategories={setCategories}
            />
          )}
        </Stack.Screen>

        <Stack.Screen name="Category">
          {(props) => (
            <CategoryScreen
              {...props}
              categories={categories}
              setCategories={setCategories}
            />
          )}
        </Stack.Screen>

        <Stack.Screen name="Add Dish">
          {(props) => (
            <AddDishScreen
              {...props}
              categories={categories}
              setCategories={setCategories}
            />
          )}
        </Stack.Screen>

        <Stack.Screen name="Menu Management">
          {(props) => (
            <MenuManagementScreen
              {...props}
              categories={categories}
              setCategories={setCategories}
            />
          )}
        </Stack.Screen>

        <Stack.Screen name="Edit Dish">
          {(props) => (
            <DishEditScreen
              {...props}
              categories={categories}
              setCategories={setCategories}
            />
          )}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
